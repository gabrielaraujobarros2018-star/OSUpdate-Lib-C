#!/bin/bash
# Deploy to Nexus 6 (shamu)
make clean && make -j8

adb push libOSUPDATE.so /system/lib/lumen-os/
adb push OSUPDATElib.h /system/include/
adb shell "ldconfig && depmod -a"

echo "✅ OSUPDATElib v1.0 deployed to Nexus 6"
echo "   Size: $(stat -c %s libOSUPDATE.so) bytes"
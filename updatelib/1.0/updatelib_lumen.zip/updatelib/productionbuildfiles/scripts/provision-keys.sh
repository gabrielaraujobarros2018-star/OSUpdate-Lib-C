#!/bin/bash
# Production key provisioning
openssl genrsa -out lumen-root.key 2048
openssl rsa -in lumen-root.key -pubout -out lumen-root.pub
xxd -i lumen-root.pub > keys.h
echo "Production keys generated: lumen-root.{key,pub}"